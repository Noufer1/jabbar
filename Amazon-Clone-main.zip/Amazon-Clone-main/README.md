# Amazon Clone Project

This is a clone of the Amazon website created using HTML and CSS. 

The project is still in progress and JavaScript will be added soon.

## [Click Here to Open](https://amankumarsinhagithub.github.io/Amazon-Clone/)

## Note : 
If you are opening the site in mobile phone, Please open in Desktop Mode

## Preview Images:

![preview-img](https://github.com/AmanKumarSinhaGitHub/Amazon-Clone/assets/65329366/fdaf5ab3-ba15-41ff-88a0-bf6d27b9ab6c)

## Contributing

Contributions are welcome! Please feel free to submit a pull request.
